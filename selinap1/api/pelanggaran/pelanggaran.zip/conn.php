<?php
    //('<host>','username','password','<nama_db>')
    $db = mysqli_connect('localhost','root','','selinap');
?>